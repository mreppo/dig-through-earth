# Theme system (mode x scheme)

The visual language is a 2 x 2 matrix. Two HTML attributes on `<html>` control everything:

| Attribute | Values | What it controls |
|---|---|---|
| `data-mode` | `kid` (default) / `standard` | Type scale, radii, motion, tap-target sizes, button shape |
| `data-scheme` | `light` / `dark` (initial: follow `prefers-color-scheme`) | Palette, glass surfaces, ink, shadows |

The four combinations:

| | Light | Dark |
|---|---|---|
| **Kid** | Peach + pink + sky-blue daylight, big rounded type, pill buttons, 56 px tap targets, spring overshoot. **Default for kids in daylight.** | Night-sky aurora, vivid amber + coral + teal + violet accents. Default if OS is in dark mode. |
| **Standard** | Cool warm-grey daylight, calmer accents, tighter type, rounded-rect buttons, 44 px tap targets, no overshoot. | Same calmer accents on the dark aurora wallpaper. |

## Mascot: the mode switcher

```
┌──────────────────────────────────────────┐
│  Dig Through Earth.    ☀   🐭+⛑          │
│                                [KID]     │
└──────────────────────────────────────────┘
```

- **Mole button** (56 x 56) on the top-right of every screen. **Tap it = flip mode** (kid <-> standard). Eight dirt-puff particles burst outward; mole rotates 360° on Y-axis over 520 ms.
- Below the mole sits a 9-px mode pill: `KID` (amber) or `STD` (ink).

## Sun / moon: the scheme switcher

- A smaller 44-px glass button **immediately to the left of the mole**.
- Shows the **current** scheme glyph (sun in light, moon in dark). Tap it to flip.
- The glyph rotates 360° on tap (320-520 ms depending on mode).

## Default state and persistence

- **First visit**, `<html>` has `data-mode="kid"` and `data-scheme=` whichever the OS prefers (via `prefers-color-scheme`).
- Mole tap writes `dte:mode` to `localStorage`. Sun/moon tap writes `dte:scheme` to `localStorage`.
- A user that has touched scheme **opts out of system following**. The app no longer reacts to OS changes after that. (Tested behaviour: this matches what kids expect - tap the button, the answer stays.)
- A user who has only touched the mole still follows the OS for scheme.

### No-FOUC boot script (inline in `<head>` before any stylesheet)

```html
<script>
  (function () {
    try {
      var m  = localStorage.getItem('dte:mode')   || 'kid';
      var s  = localStorage.getItem('dte:scheme');
      if (!s) {
        s = matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
      }
      document.documentElement.setAttribute('data-mode', m);
      document.documentElement.setAttribute('data-scheme', s);
    } catch (e) {}
  })();
</script>
```

This must run before `tokens.css` loads or returning users will flash the default.

## Behaviour reference

| Trigger | Effect |
|---|---|
| Tap mole | `data-mode` flips. Mole rotates 360°. Dirt-puff burst. `dte:mode` persisted. `navigator.vibrate(8)` on Android. |
| Tap sun/moon | `data-scheme` flips. Glyph rotates 360°. `dte:scheme` persisted. `navigator.vibrate(6)`. Opts out of OS following. |
| OS scheme change (mode never overridden) | `data-scheme` updates automatically. No notification, no animation. |
| Focus-visible | 3 px accent ring with 3-4 px offset. |
| `prefers-reduced-motion: reduce` | All flip animations become a 1 ms swap. No vibrate. |
| `prefers-reduced-transparency: reduce` | Glass surfaces become opaque solids. Buttons keep their fills. |

## Accessibility

- Mole `aria-label` updates: `Switch to standard look (currently kid mode)` and vice versa. `aria-pressed` mirrors the binary state.
- Sun/moon `aria-label` updates: `Switch to dark mode (currently light)` and vice versa. `aria-pressed` mirrors the binary state.
- Mode pill and the SVG glyphs are `aria-hidden="true"` - the button's `aria-label` carries the meaning.
- Keyboard: `Enter` / `Space` triggers each toggle.

## Token consumption

Every component reads tokens by name. The CSS never references the specific attribute combinations except in `tokens.css` itself and a handful of polish lines (e.g. the drilling overlay deliberately stays dark in light mode). To add a new component, just use the tokens.

```css
/* Good - works in all 4 combinations */
.my-card {
  background: var(--dte-glass-bg);
  backdrop-filter: var(--dte-glass-blur);
  border-radius: var(--dte-r-card);
  color: var(--dte-ink);
  padding: var(--dte-s-5);
}
```

```css
/* Bad - hardcodes a scheme */
.my-card {
  background: rgba(255,255,255,.6);
  color: #000;
}
```

## Reference implementation

See `prototype/app.js` (`applyMode`, `applyScheme`, the `mq.addEventListener` for system following) and `prototype/style.css` (`.mole-btn`, `.scheme-btn`, the `[data-scheme="dark"]` glyph-switch rules, and the `@keyframes flip` / `schemeSwap` blocks).
