# String additions (EN + LV)

Merge into `i18n/en.json` AND `i18n/lv.json` in the same commit. Run `python3 scripts/check-i18n.py` to verify parity. Send the LV column to the `latvian-kids-translator` sub-agent before opening the PR - the draft below is a starting point, not final.

## Conventions

- **No em dashes anywhere**. Use a hyphen with spaces on both sides: ` - `. The existing repo also follows this (CLAUDE.md / EU style).
- **No exclamation marks in standard mode**. Kid mode allows them in clearly playful contexts (`Yes!`, `Whoa!`).
- LV uses informal **tu** form. Never `Jūs`. Diminutives are welcome in kid copy (`atradām`, `iznāksi`).
- Numbers stay bare (`5 dienas`, not `5 Dienas`). Metric units only.
- Both languages must move together (CI gate: `scripts/check-i18n.py`).

## New keys

| Key | EN (kid mode default) | LV draft (for translator review) |
|---|---|---|
| `header.wordmark` | `Dig Through Earth` | `Izrok cauri Zemei` |
| `theme.label` | `Theme` | `Izskats` |
| `theme.kid` | `Kid` | `Bērnu` |
| `theme.standard` | `Standard` | `Standarta` |
| `theme.switchTo.kid` | `Switch to kid look (currently standard mode)` | `Pārslēgt uz bērnu izskatu (pašlaik standarta režīms)` |
| `theme.switchTo.standard` | `Switch to standard look (currently kid mode)` | `Pārslēgt uz standarta izskatu (pašlaik bērnu režīms)` |
| `theme.pill.kid` | `KID` | `BĒRNU` |
| `theme.pill.standard` | `STD` | `STD` |
| `mascot.alt` | `Dig mole mascot - tap to change theme` | `Krots-rakšus, mūsu maskots - pieskaries, lai mainītu izskatu` |
| `locator.eyebrow` | `Hi explorer` | `Sveiks, pētniek` |
| `locator.heading` | `Where are you right now?` | `Kur tu šobrīd esi?` |
| `locator.subtitle` | `Pick a spot - we'll dig straight through Earth and show you where you'd come out.` | `Izvēlies vietu - mēs izraksim cauri Zemei un parādīsim, kur tu iznāktu.` |
| `locator.method.gps.label` | `Use my location` | `Atrodi mani` |
| `locator.method.gps.sub` | `We'll ask your permission` | `Vispirms pajautāsim atļauju` |
| `locator.method.map.label` | `Tap a map` | `Pieskaries kartei` |
| `locator.method.map.sub` | `Pick anywhere on Earth` | `Izvēlies jebkuru vietu uz Zemes` |
| `locator.search.placeholder` | `Search a city or town...` | `Meklē pilsētu vai ciematu...` |
| `locator.search.label` | `Search a city or town` | `Meklēt pilsētu vai ciematu` |
| `locator.cities.heading` | `Or pick a city` | `Vai izvēlies pilsētu` |
| `locator.cities.riga` | `Rīga` | `Rīga` |
| `locator.cities.berlin` | `Berlin` | `Berlīne` |
| `locator.cities.paris` | `Paris` | `Parīze` |
| `locator.cities.madrid` | `Madrid` | `Madride` |
| `locator.cities.rome` | `Rome` | `Roma` |
| `locator.cities.stockholm` | `Stockholm` | `Stokholma` |
| `result.youTag` | `You` | `Tu` |
| `result.antipodeTag` | `Come out` | `Iznāksi` |
| `result.heading` | `Your antipode` | `Tavs antipods` |
| `result.openWater` | `Open water` | `Atklāts ūdens` |
| `result.statThrough` | `Through Earth` | `Cauri Zemei` |
| `result.statSurface` | `Around surface` | `Apkārt virsmai` |
| `result.fact.whales` | `If you're in Europe, your antipode is in the ocean **97 %** of the time. Say hi to the whales!` | `Ja tu esi Eiropā, tavs antipods 97 % gadījumu ir okeānā. Pasveicini vaļus!` |
| `result.cta.seeMap` | `See on map` | `Parādi kartē` |
| `result.cta.spinGlobe` | `Spin the globe` | `Pagriez globusu` |
| `view.mapShort` | `2D map` | `2D karte` |
| `view.globeShort` | `3D globe` | `3D globuss` |
| `globe.peek.through` | `straight through Earth` | `taisni cauri Zemei` |
| `globe.controls.spin` | `Spin globe` | `Pagriezt globusu` |
| `globe.controls.reset` | `Reset view` | `Atiestatīt skatu` |
| `map.controls.zoomIn` | `Zoom in` | `Pietuvināt` |
| `map.controls.zoomOut` | `Zoom out` | `Attālināt` |
| `map.controls.recenter` | `Recenter` | `Centrēt no jauna` |
| `drilling.title` | `Drilling through Earth...` | `Rokam cauri Zemei...` |
| `drilling.sub` | `Hold tight, this takes a moment` | `Turies stipri, brīdis tikai` |
| `quiz.head.short` | `Quick quiz` | `Ātrā viktorīna` |
| `quiz.feedback.next` | `Next question` | `Nākamais jautājums` |
| `quiz.feedback.finish` | `See results` | `Skatīt rezultātus` |
| `quiz.end.score.brief` | `{{correct}} of {{total}}` | `{{correct}} no {{total}}` |
| `notFound.eyebrow` | `404` | `404` |
| `notFound.heading` | `Lost in the tunnel` | `Apmaldījies tunelī` |
| `notFound.body` | `Looks like you dug the wrong way! Let's get you back to the surface.` | `Šķiet, izraki nepareizajā virzienā! Atgriezīsimies virspusē.` |
| `notFound.cta` | `Back to the surface` | `Atpakaļ uz virsmu` |
| `back` | `Back` | `Atpakaļ` |

## Open-ocean wording (covers 97 % of EU antipodes)

`results.placeName.openOcean.south_pacific` -> `South Pacific Ocean` / `Klusā okeāna dienvidi`
`results.placeName.openOcean.southern` -> `Southern Ocean` / `Dienvidu okeāns`
`results.placeName.openOcean.south_indian` -> `South Indian Ocean` / `Indijas okeāna dienvidi`
`results.placeName.openOcean.generic` -> `Open ocean` (existing key, keep)

## Notes for the LV translator sub-agent

1. `Dig mole mascot` - the mascot is a mole wearing a yellow hardhat. **`Krots-rakšus`** is a playful, kid-friendly Latvian name (literally "Mole-dig-and-dig"). If you prefer something punchier (`Rocelis`, `Tunelītis`, etc.), suggest in PR review.
2. The Latvian for `antipode` is `antipods` (already used in the live site). Keep.
3. `Brittle 97 %` formatting: LV uses non-breaking space between number and `%` per LV typography convention. Use `\u00a0%` in source.
4. `Hi explorer` -> `Sveiks, pētniek`. If a girl plays the game, screen-reader announces masculine vocative; LV grammar makes the neutral form awkward. Stick with masculine vocative as informal convention.
