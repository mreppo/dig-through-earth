# Components & screens

One section per screen. Each section lists the components introduced, the existing JS module that drives the behaviour (per CLAUDE.md file layout), and the a11y fallbacks called out explicitly.

> **Convention.** All sizes refer to mobile 390 x 844. Padding values are tokenised (`var(--dte-s-N)`).

---

## Shared chrome (every screen)

### Status bar spacer
- Fixed 54 px top inset, transparent. The real iOS status bar paints over this in PWA / home-screen mode. No content lives here.

### Topbar
- 56-64 px tall, padding `0 var(--dte-screen-pad-x)`, contains:
  - Left: back chevron (icon button, 56 x 56 in kid / 44 x 44 in standard) **or** wordmark
  - Centre: optional screen title (caption weight)
  - Right: **mole theme switcher** (see `theme-switcher.md`)

### Tab bar
- Floating glass pill, 64 px tall, 16 px from screen edges, `bottom: calc(env(safe-area-inset-bottom) + 18px)`. Four slots: Dig, Map, Globe, Quiz. Active slot is amber-filled pill with `box-shadow: 0 4px 12px rgba(255,182,39,.4)`. Inactive slots are ink-soft, icon-only-on-press would be too cryptic so labels are always visible (10 px 700 weight).
- **A11y:** `nav[aria-label="Main"]`, each tab has `aria-current="page"` when active.

---

## Screen 1 - Landing / Locator

### Components
| Component | Notes |
|---|---|
| Hero block | Eyebrow + display-size question + body subtitle. Display is `var(--dte-t-display)` (44 px kid / 36 px standard). |
| Mini-globe preview | 200 px static decorative element, a 152 px globe orb with an animated pin pulse. Pure CSS (no canvas). |
| Method cards | Two glass cards in a 2-col grid: "Use my location" and "Tap a map". Each is min 116 px tall, 40 x 40 icon square with white icon and `var(--dte-sh-icon-sq)` inset shadow. |
| Search field | Pill-shaped glass input, 56 px tall, magnifier glyph leading. Live-filters Nominatim results when the user types (use existing `js/location.js` debounce). |
| City chips | Horizontal-wrap row of 6 EU cities with flag emoji. 40 px tall, 14 px font. Tapping a chip sets coords from a hard-coded EU city list - no network needed (privacy-friendly default). |

### JS hooks
- `js/main.js` mounts the screen, calls `js/location.js` for GPS, `js/antipode.js` for the math, then transitions to result.
- City chips read coords from a constant in `js/location.js` (add `EU_CITIES` map).

### A11y fallbacks
- Method cards: each is a `<button>` with a descriptive `aria-label` (the visible "We'll ask your permission" sub-line is in the accessible name).
- City chips: same. Flag emojis carry `aria-hidden="true"`.
- Search input has a visually-hidden `<label>` referenced by `aria-labelledby`.
- The mini-globe orb is `aria-hidden="true"` - decorative only.
- GPS permission denied / unsupported / timeout fall back to the search field (existing keys `locator.errors.*`).

---

## Screen 2 - Antipode result

### Components
| Component | Notes |
|---|---|
| Dig line | Vertical 3 px line between the two place cards, gradient `accent -> accent-2 -> accent-4`. Pure decorative (`aria-hidden`). |
| Place card (origin) | Glass-strong, "You" tag in teal, place name in title-xl, coords in mono caption. |
| Place card (antipode) | Same shape, "Come out" tag in violet (`var(--dte-accent-4)`), name + coords. If the antipode is in the ocean, name shows `Open ocean` and a secondary line shows `Open water`. |
| Stat cards | Two-up grid: through-Earth (12,742 km) and around-surface (~20,000 km). Glass cards, eyebrow label + 22 px value with smaller unit. |
| Fun fact card | Glass with a 22 %/18 % tinted overlay (accent-2 + accent-4). Single emoji on the left, body copy on the right. Strong-weight numeric. |
| CTA pair | "See on map" (secondary glass) + "Spin the globe" (primary amber). |

### A11y fallbacks
- The two place cards are an `<ol>` semantically - they ARE a sequence (origin -> antipode). The dig line is purely decorative.
- Fun fact card uses `<p>` with the emoji as inline decoration (`aria-hidden="true"`). The text alone carries the message.
- Stat values: include the unit inside the value's accessible text (`12,742 km`), not as a separate visual unit only.

### Drilling transition (medium dig moment, 1.3 s)
- Full-screen overlay with the rotating earth + pulsing lava core.
- Triggered when a locator method completes; intercepts the route change so the result screen lands feeling intentional.
- `role="status" aria-live="polite"` with text `Drilling through Earth...`. Screen reader announces "Drilling through Earth" once.
- Under `prefers-reduced-motion`, the overlay still shows for 200 ms (so the route change isn't jarring) but the rotation is removed.

---

## Screen 3 - 2D Map (Leaflet)

### Components
| Component | Notes |
|---|---|
| Map canvas | Existing Leaflet instance. We do **not** restyle the map tiles. |
| View toggle | Floating pill at `top: 70px center`, switches between 2D and 3D. Uses `aria-pressed` on each child. |
| Zoom stack | Floating glass cluster, top-right `top: 130px`. Re-skinned Leaflet `+` and `-` buttons plus a "Recenter" tertiary action. **Important:** Leaflet's default zoom DOM stays - we only restyle its classes via CSS or wrap them. |
| Attribution pill | Bottom-right above the result peek. Re-skinned OSM attribution (which **must** stay - OSM licence). |
| Result peek | Floating glass card at bottom, shows origin -> antipode with the through-Earth distance. Single tap expands to full result screen. |

### A11y fallbacks
- View toggle is a `role="group"` with two `aria-pressed` buttons. Each button label is the spoken text ("2D map", "3D globe"), not the abbreviated visual label.
- Zoom buttons: native Leaflet a11y is good (it adds `aria-label="Zoom in"` automatically). Don't strip these when restyling.
- The map element itself has `aria-label="Map of Earth. Tap or click to pick a starting spot."` from existing i18n keys.
- For non-sighted users, the result peek is the primary surface - the map is supplemental.

---

## Screen 4 - 3D Globe (globe.gl)

### Components
| Component | Notes |
|---|---|
| Globe canvas | Existing globe.gl WebGL canvas. **Untouched.** All we change is the surrounding chrome. |
| View toggle | Same component as screen 3, with `aria-pressed="true"` on 3D globe. |
| Origin-antipode legend card | Glass-strong pill above the bottom peek, with two coloured dots + place names. Decorative dots are `aria-hidden`; place names are spoken. |
| Camera controls | Two-button glass stack, top-right: "Spin globe" + "Reset view". |

### A11y fallbacks
- The globe canvas falls back to the 2D map when WebGL is unsupported - existing i18n key `view.globeUnsupported` covers the message.
- When `prefers-reduced-motion: reduce` is on, the auto-rotation stops. (The user can still manually spin it.)
- When `prefers-reduced-transparency: reduce` is on, the chrome cards become opaque solids via the existing token fallback - the globe remains.

---

## Screen 5 - Quiz

### Components
| Component | Notes |
|---|---|
| Quiz head | Progress bar (8 px tall, accent gradient fill) + "N / total" step indicator. |
| Question card | Glass-strong card with 40 px emoji header, title-md question, vertical list of four answer options. |
| Q option | Glass pill button, 56 px tall (kid) / 44 px (standard), letter badge A-D on the left, option text. Tap reveals correct/wrong state via colour-mix tints + border colour. |
| Feedback inline | Below the options after answer: `Yes, that's right!` (em accent on success) or `Not quite - the answer is **X**.` |
| Next / finish | Primary block button below feedback. Text flips to "See results" on the last question. |
| Score ring | Quiz end: SVG ring (180 x 180, 14 px stroke) showing correct/total fraction, with a 56 px number in the centre. |

### A11y fallbacks
- The option group is `role="radiogroup"` with each option `role="radio"` and `aria-checked` synced to selection.
- The progress bar is decorative; the `N / total` step is read aloud via live region `aria-live="polite"`.
- Feedback uses `role="status" aria-live="polite"` so the correct/wrong message is announced.
- Tier copy at end (`tierPerfect` / `tierHigh` / `tierMid` / `tierLow`) uses existing keys.
- Score ring is `aria-hidden`; the `{correct} of {total}` number is spoken via a sibling `<span class="visually-hidden">`.

---

## Screen 6 - 404 "Lost in the tunnel"

### Components
| Component | Notes |
|---|---|
| Tunnel rings | Four concentric expanding rings (CSS animation, 3 s loop, staggered 0.5 s) in accent / accent-2 / accent-4 / accent-3. |
| Mole-deep glyph | Smaller mole, centred inside the rings, looking up. |
| Eyebrow + heading + body | Same hierarchy as locator hero. |
| Back CTA | Primary amber pill, "Back to the surface". Goes to `/`. |

### A11y fallbacks
- The whole tunnel block is `aria-hidden="true"`. The semantic 404 content is in the heading + body + link.
- The page sets `document.title` to `Page not found - Dig Through Earth` (existing key `notFound.title`).
- Under `prefers-reduced-motion`, the rings render but don't animate. (They become four faint concentric outlines.)

---

## Empty / loading / error states

| State | Pattern |
|---|---|
| Locator: GPS denied | Friendly inline message under the GPS card, links the user to the search field. Uses existing key `locator.errors.denied`. |
| Locator: GPS timeout | Same surface, `locator.errors.timeout`. |
| Result: ocean | Place card shows `Open ocean` as the name, secondary line indicates which ocean by lat/lng band. The fun fact upgrades to celebrate the ocean instead of feeling like a near-miss. |
| Map / globe: tile load fail | Translucent error toast at the top of the canvas with a retry button. (Add new key `view.tilesFailed`.) |
| Globe: WebGL unsupported | Use existing key `view.globeUnsupported`. Auto-switch to 2D. |
| Quiz: no questions loaded | Should never happen (questions are inline data) but show `Try again later` + retry. |

## Performance notes

- Avoid animating `backdrop-filter`, `background`, or `box-shadow` on blurred surfaces. Animate `opacity` and `transform` only.
- The aurora wallpaper is a static gradient stack - no per-frame work.
- The mini-globe orb and the 3D globe placeholder on screens use pure CSS so they don't compete with globe.gl for GPU time on screen 4.
- The drilling overlay's earth-rotation uses a `transform: rotate()` keyframe, not a real spin animation on multiple layers.

## Mobile-first widths

- Primary viewport: **390 px**.
- Verify at 375 px (iPhone SE) before merge. The only spots that can pinch:
  - Method cards in the 2-col grid: shrink to 1-col if `min-width: 360px` media query trips.
  - The "Spin the globe" CTA on result screen: wrap to a column at 360 px.
- Desktop: centre the 390 px column on the aurora wallpaper (already handled by `prototype/style.css`'s default - no media query needed).
