# Dig Through Earth - iOS 26 redesign

Handoff bundle for Claude Code. Ships a refreshed visual language built on iOS 26 "Liquid Glass" with a **kid-mode-default / standard-mode-secondary** dual-theme system and a delightful **mascot-driven theme switcher**.

> All hard rules from `CLAUDE.md` honoured: vanilla HTML / CSS / JS only, CDN deps only, EN/LV parity, mobile-first 375-390 px, Lighthouse a11y >= 95, hyphens not em dashes, no tracking, no third-party fonts that phone home.

## What's in this bundle

```
handoff/
├── README.md                  - this file (top-level plan)
├── tokens.css                 - all design tokens, both themes, a11y fallbacks
├── strings-additions.md       - new EN/LV i18n keys to merge into i18n/{en,lv}.json
├── components.md              - per-screen component specs + a11y notes
└── theme-switcher.md          - the mascot toggle: spec, motion, persistence

prototype/
├── index.html                 - interactive prototype (mobile-first, 390 px)
├── tokens.css                 - same tokens, copy verbatim to css/
├── style.css                  - component CSS, copy verbatim or split per CLAUDE.md
└── app.js                     - vanilla JS, no build
```

## How to use this bundle

1. Open `prototype/index.html` on a phone (or in DevTools mobile preview) and tap the mole top-right to feel the theme switch. Use the floating prototype panel at the bottom to jump between the six screens.
2. Copy `prototype/tokens.css` into `css/tokens.css` (new file). Move existing variables from `css/main.css` into `tokens.css` if any.
3. Apply `data-theme="kid"` to `<html>` and wire the switcher per `theme-switcher.md`.
4. Add new strings from `strings-additions.md` to `i18n/en.json` AND `i18n/lv.json` in the same commit (run `python3 scripts/check-i18n.py`). Hand off LV phrasings to `latvian-kids-translator` before merging.
5. Rebuild each screen per `components.md` - reuse existing JS modules (`js/location.js`, `js/quiz.js`, etc.); only the chrome and styling change.

## High-level design decisions

### Why a 2-axis theme system (mode × scheme)?

The visual language is a **2 × 2 matrix**. Two attributes on `<html>` control everything:

| Attribute | Values | What it controls |
|---|---|---|
| `data-mode` | `kid` (default) / `standard` | Type scale, radii, motion, tap targets, button shape |
| `data-scheme` | `light` / `dark` (initial follows `prefers-color-scheme`) | Palette, glass, ink, shadows |

| | Light | Dark |
|---|---|---|
| **Kid** | Peach + pink + sky-blue daylight, big rounded type, pill buttons, 56 px tap, spring overshoot. **Default in daylight.** | Night-sky aurora, vivid accents. Default if OS is in dark mode. |
| **Standard** | Cool warm-grey daylight, calmer accents, tighter type, rounded-rect buttons, 44 px tap. | Calmer accents on dark aurora. |

Mole tap flips `mode`. Sun/moon tap flips `scheme`. Both persist in `localStorage`. See `theme-switcher.md`.

### Kid mode vs Standard mode (regardless of scheme)

Audience is 7-16. A single look that suits a 7-year-old reads as childish to a 13-year-old; a single teen look reads as cold to a 7-year-old. Two modes share one token contract so JS, layout, and i18n stay identical. **Kid is the default**.

| Dimension | Kid mode (default) | Standard mode |
|---|---|---|
| Palette | Saturated amber/coral/teal/violet | Same hues, ~25 % less saturated |
| Type | Nunito 700-900, larger sizes (display 44 px) | Inter 400-700, tighter scale (display 36 px) |
| Buttons | Pill (radius = height/2), min-height 56 px | Rounded rect (radius 16 px), min-height 44 px |
| Motion | Spring overshoot 520 ms (cubic-bezier(.34,1.56,.64,1)) | Calm cubic 320 ms, no overshoot |
| Press scale | 0.92 | 0.97 |
| Emoji | Encouraged on results, fun facts, quiz | Restrained: weather/fact only, no decorative |

*The scheme axis (light vs dark) is orthogonal: each mode renders against either the daylight peach wallpaper or the night-sky aurora.*

### Why a mascot + sun/moon for switching?

A toggle buried in settings would be invisible to most kids. The mole mascot lives in the top-right of every screen as the only persistent visual element. A 44-px sun/moon sits beside it.

- **Mole** = mode (kid / standard).
- **Sun/moon** = scheme (light / dark, also opts out of OS following).
- Mode pill (`KID` / `STD`) under the mole keeps the current state legible at a glance.
- Both persist in `localStorage` under `dte:mode` and `dte:scheme`.

### Liquid Glass: what the web can do, what it can't

Native iOS 26 lensing uses a Metal shader that bends light through a translucent volume. **The web cannot replicate this**. The faithful-feeling fake here uses:

- `backdrop-filter: blur(24px) saturate(180%)` (paired with `-webkit-backdrop-filter`)
- Layered radial gradients on the wallpaper (the "aurora" base)
- Inner highlight stroke (`inset 0 1.5px 0 rgba(255,255,255,.45)`)
- Outer drop shadow + 0.5 px white-tinted border
- No `box-shadow` or `background` transitions on blurred surfaces (GPU stutter)

When `prefers-reduced-transparency: reduce` is set, **every glass surface becomes an opaque solid** (see `--dte-glass-bg-solid` in `tokens.css`). When `prefers-reduced-motion: reduce` is set, **all transitions reduce to 1 ms** and the press scale becomes 1.

### Accessibility (the >= 95 floor)

- Every interactive element has a min tap target of 44 px (standard) or 56 px (kid).
- Focus ring is `3px solid var(--dte-accent)` with 2 px offset, **never overridden**.
- Color contrast: ink-on-glass tested AA against the dark wallpaper; ink-on-accent tested AA against amber.
- All icons have `aria-hidden="true"`; their semantic meaning lives on the parent button's `aria-label`.
- The drilling overlay is `role="status" aria-live="polite"`.
- Quiz options are a `role="radiogroup"`, options `role="radio"`, with `aria-checked`.
- View toggle is `role="group"` with `aria-pressed` on each child.

## Hand-off checklist for the implementing PR

- [ ] `css/tokens.css` added, imported before `css/main.css`
- [ ] Inline no-FOUC boot script in `<head>` (see `theme-switcher.md`) sets `data-mode` and `data-scheme` before the stylesheet loads
- [ ] `<html data-mode="kid" data-scheme="light|dark">` (the latter resolved from `prefers-color-scheme` on first visit)
- [ ] Mole + sun/moon mounted on every screen (or in a global header)
- [ ] All four combinations (kid/std × light/dark) verified at 375 px
- [ ] Existing screens reskinned per `components.md`
- [ ] New EN + LV strings added (`strings-additions.md`), `check-i18n.py` passes
- [ ] LV strings reviewed via `latvian-kids-translator` sub-agent
- [ ] Lighthouse a11y >= 95 on `/`, `/?view=globe`, `/quiz`, `/404` **in both light and dark**
- [ ] `prefers-reduced-transparency: reduce` tested in both schemes
- [ ] `prefers-reduced-motion: reduce` tested in both modes
- [ ] OS scheme change while app is open: scheme follows if user hasn't overridden
- [ ] Leaflet zoom buttons + OSM attribution still present (reskinned, not removed)
- [ ] globe.gl canvas untouched - only chrome is new
