/* ============================================================
   Dig Through Earth - Prototype JS (vanilla, no build)
   Two axes:
     mode   = "kid" | "standard"   (persisted: dte:mode)
     scheme = "light" | "dark"     (persisted: dte:scheme, "system" = follow OS)
   ============================================================ */

(function () {
  'use strict';

  const root = document.documentElement;
  const MODE_KEY   = 'dte:mode';
  const SCHEME_KEY = 'dte:scheme';

  const moleBtn   = document.getElementById('moleBtn');
  const modePill  = document.getElementById('modePill');
  const schemeBtn = document.getElementById('schemeBtn');

  // ---- System preference (only consulted when user hasn't overridden) ----
  const mq = window.matchMedia('(prefers-color-scheme: dark)');
  function systemScheme() { return mq.matches ? 'dark' : 'light'; }

  // ---- Mode (kid / standard) ----
  function applyMode(mode) {
    root.setAttribute('data-mode', mode);
    if (modePill) modePill.textContent = mode === 'kid' ? 'KID' : 'STD';
    moleBtn?.setAttribute('aria-label',
      mode === 'kid'
        ? 'Switch to standard look (currently kid mode)'
        : 'Switch to kid look (currently standard mode)');
    moleBtn?.setAttribute('aria-pressed', mode === 'standard' ? 'true' : 'false');
    document.querySelectorAll('[data-proto-mode]').forEach(btn => {
      btn.setAttribute('aria-current', btn.dataset.protoMode === mode ? 'true' : 'false');
    });
  }

  // ---- Scheme (light / dark) ----
  function applyScheme(scheme, opts) {
    opts = opts || {};
    // If 'system', resolve to current OS preference but don't write it back.
    const resolved = scheme === 'system' ? systemScheme() : scheme;
    root.setAttribute('data-scheme', resolved);
    schemeBtn?.setAttribute('aria-label',
      resolved === 'light'
        ? 'Switch to dark mode (currently light)'
        : 'Switch to light mode (currently dark)');
    schemeBtn?.setAttribute('aria-pressed', resolved === 'dark' ? 'true' : 'false');
    document.querySelectorAll('[data-proto-scheme]').forEach(btn => {
      btn.setAttribute('aria-current', btn.dataset.protoScheme === resolved ? 'true' : 'false');
    });
  }

  // ---- Dirt puff burst (mode toggle) ----
  function spawnPuffs() {
    const puff = document.querySelector('#moleBtn .dirt-puff');
    if (!puff) return;
    puff.innerHTML = '';
    const colors = ['var(--dte-accent)', 'var(--dte-accent-2)', 'var(--dte-accent-3)', 'var(--dte-accent-4)'];
    for (let i = 0; i < 8; i++) {
      const pt = document.createElement('span');
      pt.className = 'pt';
      const angle = (Math.PI * 2 * i) / 8;
      const r = 28 + Math.random() * 12;
      pt.style.setProperty('--dx', `${Math.cos(angle) * r}px`);
      pt.style.setProperty('--dy', `${Math.sin(angle) * r}px`);
      pt.style.background = colors[i % colors.length];
      pt.style.width = pt.style.height = `${4 + Math.random() * 6}px`;
      puff.appendChild(pt);
    }
  }

  // ---- Mole tap: cycle mode ----
  moleBtn?.addEventListener('click', () => {
    const next = root.getAttribute('data-mode') === 'kid' ? 'standard' : 'kid';
    spawnPuffs();
    moleBtn.classList.remove('flipping');
    void moleBtn.offsetWidth;
    moleBtn.classList.add('flipping');
    setTimeout(() => moleBtn.classList.remove('flipping'), 600);
    applyMode(next);
    try { localStorage.setItem(MODE_KEY, next); } catch (e) {}
    if (navigator.vibrate) navigator.vibrate(8);
  });

  // ---- Sun/moon tap: cycle scheme (also clears system-follow) ----
  schemeBtn?.addEventListener('click', () => {
    const current = root.getAttribute('data-scheme');
    const next = current === 'light' ? 'dark' : 'light';
    schemeBtn.classList.remove('swapping');
    void schemeBtn.offsetWidth;
    schemeBtn.classList.add('swapping');
    setTimeout(() => schemeBtn.classList.remove('swapping'), 600);
    applyScheme(next);
    try { localStorage.setItem(SCHEME_KEY, next); } catch (e) {}
    if (navigator.vibrate) navigator.vibrate(6);
  });

  // ---- Listen to system scheme changes ONLY when user hasn't overridden ----
  function userHasSchemeOverride() {
    try { return !!localStorage.getItem(SCHEME_KEY); } catch (e) { return false; }
  }
  mq.addEventListener?.('change', () => {
    if (!userHasSchemeOverride()) applyScheme('system');
  });

  // ---- Boot ----
  let savedMode = 'kid';
  let savedScheme = null;
  try {
    savedMode = localStorage.getItem(MODE_KEY) || 'kid';
    savedScheme = localStorage.getItem(SCHEME_KEY);
  } catch (e) {}
  applyMode(savedMode);
  applyScheme(savedScheme || 'system');

  // ---- Screen routing ----
  const screens = document.querySelectorAll('.screen');
  const tabs = document.querySelectorAll('[data-screen-target]');
  const protoBtns = document.querySelectorAll('[data-proto-screen]');

  function showScreen(id) {
    screens.forEach(s => s.setAttribute('data-active', s.id === id ? 'true' : 'false'));
    tabs.forEach(t => {
      t.setAttribute('aria-current', t.dataset.screenTarget === id ? 'page' : 'false');
    });
    protoBtns.forEach(b => {
      b.setAttribute('aria-current', b.dataset.protoScreen === id ? 'true' : 'false');
    });
    const active = document.getElementById(id);
    const scroll = active?.querySelector('.screen-scroll');
    if (scroll) scroll.scrollTop = 0;
  }
  tabs.forEach(t => t.addEventListener('click', () => showScreen(t.dataset.screenTarget)));
  protoBtns.forEach(b => b.addEventListener('click', () => showScreen(b.dataset.protoScreen)));

  document.querySelectorAll('[data-proto-mode]').forEach(b => {
    b.addEventListener('click', () => {
      const m = b.dataset.protoMode;
      applyMode(m);
      try { localStorage.setItem(MODE_KEY, m); } catch (e) {}
    });
  });
  document.querySelectorAll('[data-proto-scheme]').forEach(b => {
    b.addEventListener('click', () => {
      const s = b.dataset.protoScheme;
      applyScheme(s);
      try { localStorage.setItem(SCHEME_KEY, s); } catch (e) {}
    });
  });

  // ---- Locator interactions ----
  document.querySelectorAll('[data-method]').forEach(card => {
    card.addEventListener('click', () => runDrillAndGoToResult(card.dataset.method));
  });
  document.querySelectorAll('[data-city]').forEach(chip => {
    chip.addEventListener('click', () => runDrillAndGoToResult('city', chip.dataset.city || 'Rīga'));
  });
  document.querySelector('[data-go-quiz]')?.addEventListener('click', () => {
    resetQuiz();
    showScreen('screen-quiz');
  });

  // ---- "Drilling" transition ----
  const drillOverlay = document.getElementById('drilling');
  function runDrillAndGoToResult(method, place) {
    drillOverlay.setAttribute('data-active', 'true');
    if (navigator.vibrate) navigator.vibrate([10, 80, 10]);
    setTimeout(() => {
      drillOverlay.setAttribute('data-active', 'false');
      showScreen('screen-result');
    }, 1300);
  }

  // ---- View toggle on map screen ----
  document.querySelectorAll('[data-view-target]').forEach(b => {
    b.addEventListener('click', () => {
      const tgt = b.dataset.viewTarget;
      document.querySelectorAll('[data-view-target]').forEach(x => {
        x.setAttribute('aria-pressed', x.dataset.viewTarget === tgt ? 'true' : 'false');
      });
      showScreen(tgt === 'globe' ? 'screen-globe' : 'screen-map');
    });
  });

  // ---- Quiz ----
  const quizData = [
    { emoji: '🇱🇻', q: 'If you dig straight through Earth from Latvia, where do you come out?',
      options: ['Pacific Ocean', 'Brazil', 'Australia', 'China'], answer: 0 },
    { emoji: '🌊', q: 'Which ocean is the deepest?',
      options: ['Atlantic Ocean', 'Pacific Ocean', 'Indian Ocean', 'Arctic Ocean'], answer: 1 },
    { emoji: '⏱️', q: 'If you could fall through a tunnel right through Earth (no heat, no air), how long would it take?',
      options: ['About 42 minutes', 'About 1 hour', 'About 1 day', 'About 1 week'], answer: 0 },
    { emoji: '🌍', q: 'If you pick a random spot in Europe, where is your antipode most likely to be?',
      options: ['Asia', 'South America', 'Pacific Ocean', 'Antarctica'], answer: 2 },
    { emoji: '📏', q: 'Earth\u2019s diameter - the straight line through the middle - is about...',
      options: ['5,000 km', '12,742 km', '40,000 km', '100,000 km'], answer: 1 },
  ];

  let quizIdx = 0, quizScore = 0, quizAnswered = false;

  function renderQuiz() {
    const card = document.getElementById('quizCard');
    if (!card) return;
    const total = quizData.length;
    if (quizIdx >= total) { renderQuizEnd(); return; }
    const item = quizData[quizIdx];
    document.getElementById('quizFill').style.width = `${(quizIdx / total) * 100}%`;
    document.getElementById('quizStep').textContent = `${quizIdx + 1} / ${total}`;

    card.innerHTML = `
      <div class="q-emoji" aria-hidden="true">${item.emoji}</div>
      <p class="q-text">${item.q}</p>
      <div class="q-options" role="radiogroup" aria-label="Answer options">
        ${item.options.map((o, i) => `
          <button class="q-option" data-idx="${i}" role="radio" aria-checked="false">
            <span class="badge" aria-hidden="true">${String.fromCharCode(65 + i)}</span>
            <span class="text">${o}</span>
          </button>
        `).join('')}
      </div>
      <div class="q-feedback hide" id="qFeedback" role="status" aria-live="polite"></div>
      <button class="btn btn-primary btn-block hide" id="qNext" style="margin-top: 16px;">Next question</button>
    `;
    quizAnswered = false;

    card.querySelectorAll('.q-option').forEach(btn => {
      btn.addEventListener('click', () => {
        if (quizAnswered) return;
        quizAnswered = true;
        const i = +btn.dataset.idx;
        const correct = i === item.answer;
        if (correct) quizScore++;
        card.querySelectorAll('.q-option').forEach((b, bi) => {
          b.disabled = true;
          if (bi === item.answer) b.classList.add('correct');
          if (bi === i && !correct) b.classList.add('wrong');
          b.setAttribute('aria-checked', bi === i ? 'true' : 'false');
        });
        const fb = document.getElementById('qFeedback');
        fb.classList.remove('hide');
        fb.innerHTML = correct
          ? `<span class="em">Yes, that\u2019s right!</span>`
          : `Not quite - the answer is <span class="em">${item.options[item.answer]}</span>.`;
        const next = document.getElementById('qNext');
        next.classList.remove('hide');
        next.textContent = quizIdx === total - 1 ? 'See results' : 'Next question';
        next.addEventListener('click', () => { quizIdx++; renderQuiz(); }, { once: true });
        if (navigator.vibrate) navigator.vibrate(correct ? 6 : [4, 60, 4]);
      });
    });
  }

  function renderQuizEnd() {
    const card = document.getElementById('quizCard');
    const total = quizData.length;
    const pct = quizScore / total;
    let tier = 'Try again, adventurer - the Earth has more secrets!';
    if (pct === 1) tier = 'Whoa - a perfect score! You\u2019re a real Earth detective.';
    else if (pct >= 0.7) tier = 'Brilliant - you really are a geography explorer!';
    else if (pct >= 0.4) tier = 'Nice digging - you know your planet pretty well!';

    const r = 78, c = 2 * Math.PI * r;
    const offset = c - (pct * c);
    document.getElementById('quizFill').style.width = '100%';
    document.getElementById('quizStep').textContent = `Done`;
    card.innerHTML = `
      <div class="score-ring" aria-hidden="true">
        <svg viewBox="0 0 180 180">
          <circle class="ring-bg" cx="90" cy="90" r="${r}" fill="none" stroke-width="14" />
          <circle class="ring-fg" cx="90" cy="90" r="${r}" fill="none" stroke-width="14"
                  stroke-dasharray="${c}" stroke-dashoffset="${offset}" />
        </svg>
        <div class="num">${quizScore}<span class="of">of ${total}</span></div>
      </div>
      <h2 class="h-lg" style="text-align:center; margin-bottom: 10px;">${tier}</h2>
      <button class="btn btn-primary btn-block btn-lg" id="quizReplay" style="margin-top:18px;">Play again</button>
    `;
    document.getElementById('quizReplay').addEventListener('click', resetQuiz);
  }

  function resetQuiz() { quizIdx = 0; quizScore = 0; quizAnswered = false; renderQuiz(); }
  if (document.getElementById('quizCard')) renderQuiz();

  // ---- Keyboard nav between screens ----
  document.addEventListener('keydown', (e) => {
    if (e.target.matches('input, textarea, button')) return;
    const order = ['screen-locator', 'screen-result', 'screen-map', 'screen-globe', 'screen-quiz', 'screen-404'];
    const cur = order.findIndex(id => document.getElementById(id)?.dataset.active === 'true');
    if (cur < 0) return;
    if (e.key === 'ArrowRight') showScreen(order[(cur + 1) % order.length]);
    if (e.key === 'ArrowLeft')  showScreen(order[(cur - 1 + order.length) % order.length]);
  });

  showScreen('screen-locator');
})();
